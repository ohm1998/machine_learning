Output file should contain 200 lines with predicted values as in sample_submission.csv
Please upload a zip file containing output file and documentation of your solution, and the scripts you used to make predictions which should generate the same output.
